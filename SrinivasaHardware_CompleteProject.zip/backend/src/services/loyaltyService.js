const Loyalty = require('../models/Loyalty');

const getPoints = async (userId) => {
  const customer = await Loyalty.findOne({ userId });
  return customer ? customer.points : 0;
};

const redeemPoints = async (userId) => {
  const customer = await Loyalty.findOne({ userId });
  if (!customer || customer.points < 100) {
    throw new Error('Insufficient points');
  }

  customer.points -= 100;
  await customer.save();
  return 10;
};

module.exports = { getPoints, redeemPoints };