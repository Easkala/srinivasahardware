const axios = require('axios');

const getRecommendations = async (userId) => {
  try {
    const { data } = await axios.get(`http://ai-service:8000/recommendations/${userId}`);
    return data;
  } catch (error) {
    throw new Error('Failed to fetch recommendations: ' + error.message);
  }
};

module.exports = { getRecommendations };