const express = require('express');
const RecommendationService = require('../services/recommendationService');
const router = express.Router();

router.get('/:userId', async (req, res) => {
  try {
    const recommendations = await RecommendationService.getRecommendations(req.params.userId);
    res.status(200).json(recommendations);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;