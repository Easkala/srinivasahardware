const express = require('express');
const LoyaltyService = require('../services/loyaltyService');
const router = express.Router();

router.get('/:userId', async (req, res) => {
  try {
    const points = await LoyaltyService.getPoints(req.params.userId);
    res.status(200).json(points);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/:userId/redeem', async (req, res) => {
  try {
    const discount = await LoyaltyService.redeemPoints(req.params.userId);
    res.status(200).json({ discount });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;