import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';

const Dashboard = () => {
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('/api/analytics/sales');
      const data = await response.json();
      setSalesData(data);
    };
    fetchData();
  }, []);

  const chartData = {
    labels: salesData.map((item) => item.date),
    datasets: [
      {
        label: 'Sales',
        data: salesData.map((item) => item.amount),
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
      },
    ],
  };

  return (
    <div>
      <h2>Sales Dashboard</h2>
      <Line data={chartData} />
    </div>
  );
};

export default Dashboard;